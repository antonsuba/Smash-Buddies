Downloaded from:

http://www.contralogic.com/256-nes-samples/

A collection of 256 short percussive samples produced by the 2A03 soundchip in the NES console in 48kHz 16-bit WAV format.

You are free to use these samples for any purpose, but please don't redistribute them in their original form. Post the link above if you want to share them.